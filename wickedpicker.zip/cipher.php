<?php
function cipher($pass){

    return(substr($pass,0,6));
}
function cipher1($pass){

    return(substr($pass,7,13));
}
?>